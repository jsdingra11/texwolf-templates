#!/usr/bin/env python3
"""
tor_crawler_phases.py

Phase 1: seed discovery (crawl a "sample Hidden Wiki" and write discovered .onion links to links.txt live)
Phase 2: depth crawl using links.txt as seeds

Usage examples:
  # Phase 1 only (discover seeds)
  python3 tor_crawler_phases.py --phase 1

  # Phase 2 only (use existing links.txt as seeds)
  python3 tor_crawler_phases.py --phase 2

  # Do both: discover then deep-crawl
  python3 tor_crawler_phases.py --phase both

  # wipe links file before Phase 1
  python3 tor_crawler_phases.py --phase 1 --wipe-links

  # skip robots.txt checks (not recommended except for local testing)
  python3 tor_crawler_phases.py --phase 1 --skip-robots
"""

import argparse
import os
import re
import time
import sqlite3
from collections import deque
from datetime import datetime
from urllib.parse import urljoin, urlparse, urldefrag, urlunparse, unquote, quote
import posixpath

import requests
from bs4 import BeautifulSoup
from urllib.robotparser import RobotFileParser

# ---------------- CONFIG DEFAULTS ----------------
DEFAULT_TOR_SOCKS = "socks5h://127.0.0.1:9150"  # Tor Browser default. change to 9050 if system tor
PROXIES = {"http": DEFAULT_TOR_SOCKS, "https": DEFAULT_TOR_SOCKS}
USER_AGENT = "MiniTorCrawler/phase1-2 (+contact: you@example.com)"
HEADERS = {"User-Agent": USER_AGENT}
REQUEST_TIMEOUT = 20
DELAY_BETWEEN_REQUESTS = 2.0

DEFAULT_LINKS_FILE = "links.txt"
DB_PATH = "index.db"

# Seeds for Phase 1 (replace with your sample Hidden Wiki URL(s))
DEFAULT_SEED_URLS = [
    # sample Hidden Wiki seed (example). Replace with your own sample.
    "http://zqktlwiuavvvqqt4ybvgvi7tyo4hjl5xgfuvpdf6otjiycgwqbym2qad.onion/wiki/index.php/Main_Page"
]

# SQLite schema
CREATE_SQL = """
CREATE TABLE IF NOT EXISTS pages (
    id INTEGER PRIMARY KEY,
    url TEXT UNIQUE,
    title TEXT,
    status INTEGER,
    depth INTEGER,
    fetched_at TEXT
);

CREATE TABLE IF NOT EXISTS links (
    id INTEGER PRIMARY KEY,
    from_url TEXT,
    to_url TEXT
);

CREATE INDEX IF NOT EXISTS idx_pages_url ON pages(url);
CREATE INDEX IF NOT EXISTS idx_links_from ON links(from_url);
"""

# ---------------- UTIL: URL canonicalization ----------------
def canonicalize(url: str) -> str:
    """Return canonicalized URL (lowercase scheme/host, normalized path, keep query)."""
    try:
        parsed = urlparse(url)
    except Exception:
        return url
    scheme = parsed.scheme.lower()
    netloc = parsed.netloc.lower()
    path = parsed.path or "/"
    upath = unquote(path)
    np = posixpath.normpath(upath)
    if not upath.startswith("/"):
        np = np.lstrip("/")
    if np == ".":
        np = "/"
    # strip trailing slash except root
    if np.endswith("/") and np != "/":
        np = np.rstrip("/")
    safe_path = quote(np, safe="/%:@+,&?;=")
    return urlunparse((scheme, netloc, safe_path, "", parsed.query or "", ""))

def normalize_url(base: str, href: str):
    """Resolve relative href against base, remove fragments, then canonicalize."""
    if not href:
        return None
    href = href.strip()
    if href.startswith(("javascript:", "mailto:", "data:", "tel:")):
        return None
    try:
        joined = urljoin(base, href)
    except Exception:
        return None
    joined, _ = urldefrag(joined)
    return canonicalize(joined)

def is_onion(url: str) -> bool:
    try:
        p = urlparse(url)
        return bool(p.hostname and p.hostname.lower().endswith(".onion"))
    except Exception:
        return False

# ---------------- DB ----------------
def init_db(path=DB_PATH):
    conn = sqlite3.connect(path)
    cur = conn.cursor()
    for q in CREATE_SQL.strip().split(";"):
        if q.strip():
            cur.execute(q)
    conn.commit()
    return conn

def save_page(conn, url, title, status, depth):
    cur = conn.cursor()
    now = datetime.utcnow().isoformat()
    try:
        cur.execute(
            "INSERT OR REPLACE INTO pages (url, title, status, depth, fetched_at) VALUES (?, ?, ?, ?, ?)",
            (url, title, status, depth, now)
        )
        conn.commit()
    except Exception as e:
        print(f"[DB] save_page error for {url}: {e}")

def save_link_db(conn, from_url, to_url):
    cur = conn.cursor()
    try:
        cur.execute("INSERT INTO links (from_url, to_url) VALUES (?, ?)", (from_url, to_url))
        conn.commit()
    except Exception:
        # ignore DB duplicate/constraint errors
        pass

# ---------------- robots.txt ----------------
def allowed_by_robots(url: str, cache: dict, proxies: dict, headers: dict, timeout: int) -> bool:
    """Fetch and cache robots.txt for host (via proxies). If fetch fails, default to allow."""
    parsed = urlparse(url)
    host_base = f"{parsed.scheme}://{parsed.netloc}"
    if host_base in cache:
        rp = cache[host_base]
        return rp.can_fetch(USER_AGENT, parsed.path or "/")
    robots_url = urljoin(host_base, "/robots.txt")
    rp = RobotFileParser()
    try:
        r = requests.get(robots_url, proxies=proxies, headers=headers, timeout=timeout)
        rp.parse(r.text.splitlines())
    except Exception:
        rp.parse([])  # empty -> allow
    cache[host_base] = rp
    return rp.can_fetch(USER_AGENT, parsed.path or "/")

# ---------------- CORE: fetch & parse ----------------
def fetch_page(url: str, proxies: dict, headers: dict, timeout: int, max_bytes: int = 2_000_000):
    """Fetch a URL (via proxies). Return tuple(status_code, text) or raise exception."""
    r = requests.get(url, proxies=proxies, headers=headers, timeout=timeout, stream=True)
    status = r.status_code
    content_type = r.headers.get("Content-Type", "")
    if "html" not in content_type and "text" not in content_type:
        # read small chunk to be sure, then return None to indicate non-HTML
        try:
            _ = r.raw.read(512)
        finally:
            r.close()
        raise ValueError(f"Non-HTML content-type: {content_type}")
    raw = r.raw.read(max_bytes + 1)
    r.close()
    if len(raw) > max_bytes:
        raw = raw[:max_bytes]
    try:
        html = raw.decode("utf-8", "replace")
    except Exception:
        html = raw.decode("latin-1", "replace")
    return status, html

# ---------------- Phase 1: seed discovery ----------------
def phase1_discover(
    seed_urls,
    links_file,
    wipe_links=False,
    proxies=PROXIES,
    headers=HEADERS,
    timeout=REQUEST_TIMEOUT,
    delay=DELAY_BETWEEN_REQUESTS,
    max_pages=200,
    skip_robots=False,
):
    """
    Crawl seed_urls shallowly (depth=1) and append discovered .onion links live to links_file.
    """
    # prepare links file
    if wipe_links and os.path.exists(links_file):
        os.remove(links_file)
    f = open(links_file, "a", encoding="utf-8")

    visited = set()
    seen_links = set()  # to avoid duplicates written to file
    robots_cache = {}
    pages_crawled = 0

    queue = deque()
    for s in seed_urls:
        queue.append((canonicalize(s), 0))

    print("[Phase 1] Starting discovery. Seeds:", len(seed_urls))
    while queue and pages_crawled < max_pages:
        url, depth = queue.popleft()
        if url in visited:
            continue
        visited.add(url)
        if not is_onion(url):
            continue

        # robots check for seed crawling (only relevant if seed is on other host)
        if not skip_robots:
            try:
                allowed = allowed_by_robots(url, robots_cache, proxies, headers, timeout)
            except Exception:
                allowed = True
            if not allowed:
                print(f"[-] robots disallow (seed): {url}")
                continue

        print(f"[Phase 1] Fetching: {url}")
        try:
            status, html = fetch_page(url, proxies, headers, timeout)
            pages_crawled += 1
            soup = BeautifulSoup(html, "html.parser")

            # 1) <a href> links (resolve relative, collect onion and same-host links)
            for a in soup.find_all("a", href=True):
                n = normalize_url(url, a["href"])
                if not n:
                    continue
                # treat same-host relative URLs as within-seed; also extract any .onion
                if is_onion(n):
                    if n not in seen_links:
                        seen_links.add(n)
                        f.write(n + "\n")
                        f.flush()
                        print(f"    + found onion link: {n}")
                else:
                    # If relative link resolved to same host but not showing .onion (edge-case),
                    # canonicalize and skip writing as onion unless hostname is .onion
                    pass

            # 2) bare .onion in visible text
            text = soup.get_text(" ")
            for m in re.findall(r"[a-z2-7]{16,56}\.onion", text):
                onion_url = "http://" + m
                onion_url = canonicalize(onion_url)
                if onion_url not in seen_links:
                    seen_links.add(onion_url)
                    f.write(onion_url + "\n")
                    f.flush()
                    print(f"    + found bare onion text: {onion_url}")

        except ValueError as ve:
            # non-HTML or other controlled skip
            print(f"    [-] skip (non-HTML or content) {url}: {ve}")
            save_page_dummy = None
        except Exception as e:
            print(f"    [-] fetch error {url}: {e}")

        time.sleep(delay)

    f.close()
    print(f"[Phase 1] Done. Discovered {len(seen_links)} unique onion links (written to {links_file}).")

# ---------------- Phase 2: deep crawl from discovered seeds ----------------
def phase2_crawl_from_linksfile(
    links_file,
    db_conn,
    proxies=PROXIES,
    headers=HEADERS,
    timeout=REQUEST_TIMEOUT,
    delay=DELAY_BETWEEN_REQUESTS,
    max_pages=500,
    max_depth=2,
    skip_robots=False,
):
    """Load seeds from links_file and perform a BFS crawl from each seed to the configured depth."""
    if not os.path.exists(links_file):
        print(f"[Phase 2] Links file {links_file} not found. Nothing to crawl.")
        return

    with open(links_file, "r", encoding="utf-8") as f:
        seeds = [line.strip() for line in f if line.strip()]
    if not seeds:
        print(f"[Phase 2] No seeds found in {links_file}.")
        return

    print(f"[Phase 2] Loaded {len(seeds)} seeds. Starting crawl (max_pages={max_pages}, max_depth={max_depth}).")
    q = deque()
    visited = set()
    robots_cache = {}
    pages_crawled = 0

    # enqueue canonical seeds
    for s in seeds:
        q.append((canonicalize(s), 0))

    while q and pages_crawled < max_pages:
        url, depth = q.popleft()
        if url in visited:
            continue
        visited.add(url)
        if not is_onion(url):
            continue

        if not skip_robots:
            try:
                allowed = allowed_by_robots(url, robots_cache, proxies, headers, timeout)
            except Exception:
                allowed = True
            if not allowed:
                print(f"[-] robots disallow: {url}")
                continue

        print(f"[Phase 2] Fetching (depth={depth}): {url}")
        try:
            status, html = fetch_page(url, proxies, headers, timeout)
            pages_crawled += 1
            soup = BeautifulSoup(html, "html.parser")
            title = soup.title.string.strip() if soup.title else None
            save_page(db_conn, url, title, status, depth)

            found = set()
            # 1) anchor links
            for a in soup.find_all("a", href=True):
                n = normalize_url(url, a["href"])
                if not n:
                    continue
                # follow same-host relative or onion links
                if is_onion(n) or (urlparse(n).netloc == urlparse(url).netloc):
                    found.add(n)
                    save_link_db(db_conn, url, n)
                    # enqueue if depth allows and not visited
                    if depth + 1 <= max_depth and n not in visited:
                        q.append((n, depth + 1))
            # 2) bare .onion in text
            text = soup.get_text(" ")
            for m in re.findall(r"[a-z2-7]{16,56}\.onion", text):
                onion_url = canonicalize("http://" + m)
                found.add(onion_url)
                save_link_db(db_conn, url, onion_url)
                if depth + 1 <= max_depth and onion_url not in visited:
                    q.append((onion_url, depth + 1))

            if found:
                print(f"    -> discovered {len(found)} new links")
            else:
                print("    -> no new links found on this page")

        except ValueError as ve:
            print(f"    [-] skipped non-HTML {url}: {ve}")
            save_page(db_conn, url, None, 415, depth)
        except Exception as e:
            print(f"    [-] fetch error {url}: {e}")
            save_page(db_conn, url, None, 500, depth)

        time.sleep(delay)

    print(f"[Phase 2] Done. Pages crawled: {pages_crawled}")

# ---------------- CLI / main ----------------
def parse_args():
    p = argparse.ArgumentParser(description="Tor crawler phases 1 (discover) and 2 (deep crawl).")
    p.add_argument("--phase", choices=("1", "2", "both"), default="both", help="Run phase 1, phase 2, or both")
    p.add_argument("--links-file", default=DEFAULT_LINKS_FILE, help="Path to the links file (default links.txt)")
    p.add_argument("--wipe-links", action="store_true", help="If set, wipe links file before Phase 1")
    p.add_argument("--skip-robots", action="store_true", help="Skip robots.txt checks (use only for testing)")
    p.add_argument("--tor-proxy", default=DEFAULT_TOR_SOCKS, help="Tor SOCKS proxy (default socks5h://127.0.0.1:9150)")
    p.add_argument("--max-pages-p1", type=int, default=200, help="Max pages to fetch in Phase 1")
    p.add_argument("--max-pages-p2", type=int, default=500, help="Max pages to fetch in Phase 2")
    p.add_argument("--max-depth", type=int, default=2, help="Max crawl depth for Phase 2")
    p.add_argument("--delay", type=float, default=DELAY_BETWEEN_REQUESTS, help="Delay between requests (seconds)")
    p.add_argument("--seed", action="append", help="Add an extra seed URL for phase 1 (can be used multiple times)")
    return p.parse_args()

def main():
    args = parse_args()

    # apply options
    global PROXIES, DELAY_BETWEEN_REQUESTS
    PROXIES = {"http": args.tor_proxy, "https": args.tor_proxy}
    DELAY_BETWEEN_REQUESTS = args.delay

    # seeds
    seeds = DEFAULT_SEED_URLS.copy()
    if args.seed:
        seeds.extend(args.seed)

    print("------- tor_crawler_phases.py -------")
    print(f"Phase to run: {args.phase}")
    print(f"Using Tor proxy: {args.tor_proxy}")
    print(f"Links file: {args.links_file}")
    print(f"Seeds: {len(seeds)}")
    print("Be sure Tor is running before starting.\n")

    # init db for phase 2
    conn = init_db(DB_PATH)

    if args.phase in ("1", "both"):
        phase1_discover(
            seed_urls=seeds,
            links_file=args.links_file,
            wipe_links=args.wipe_links,
            proxies=PROXIES,
            headers=HEADERS,
            timeout=REQUEST_TIMEOUT,
            delay=DELAY_BETWEEN_REQUESTS,
            max_pages=args.max_pages_p1,
            skip_robots=args.skip_robots,
        )

    if args.phase in ("2", "both"):
        # Phase 2 uses links_file as seeds
        phase2_crawl_from_linksfile(
            links_file=args.links_file,
            db_conn=conn,
            proxies=PROXIES,
            headers=HEADERS,
            timeout=REQUEST_TIMEOUT,
            delay=DELAY_BETWEEN_REQUESTS,
            max_pages=args.max_pages_p2,
            max_depth=args.max_depth,
            skip_robots=args.skip_robots,
        )

    print("All done. DB:", DB_PATH, "Links file:", args.links_file)

if __name__ == "__main__":
    main()
