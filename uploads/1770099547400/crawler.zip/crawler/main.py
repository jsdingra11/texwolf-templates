#!/usr/bin/env python3
"""
Tor Crawler Prototype
- Connects via Tor SOCKS proxy
- Crawls onion services (HTML only)
- Follows relative links + detects bare .onion addresses in text
- Stores results in SQLite and supports simple search
"""

import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse, urldefrag, urlunparse, unquote, quote
from urllib.robotparser import RobotFileParser
import sqlite3
import time
import sys
import re
from collections import deque
from datetime import datetime
import posixpath

# ---------------- CONFIG ----------------
TOR_SOCKS_PROXY = "socks5h://127.0.0.1:9150"  # change to 9050 if system Tor
PROXIES = {"http": TOR_SOCKS_PROXY, "https": TOR_SOCKS_PROXY}

USER_AGENT = "MiniTorCrawler/0.3 (+contact: you@example.com)"
REQUEST_TIMEOUT = 20
DELAY_BETWEEN_REQUESTS = 2.0
MAX_PAGES = 100       # limit for safety
MAX_DEPTH = 2         # keep small at first
MAX_CONTENT_BYTES = 2_000_000
HEADERS = {"User-Agent": USER_AGENT}

SEED_URLS = [
    # Hidden Wiki main page (example seed)
    "http://zqktlwiuavvvqqt4ybvgvi7tyo4hjl5xgfuvpdf6otjiycgwqbym2qad.onion/wiki/index.php/Main_Page"
]

DB_PATH = "index.db"

# ---------------- DB ----------------
CREATE_SQL = """
CREATE TABLE IF NOT EXISTS pages (
    id INTEGER PRIMARY KEY,
    url TEXT UNIQUE,
    title TEXT,
    status INTEGER,
    depth INTEGER,
    fetched_at TEXT
);

CREATE TABLE IF NOT EXISTS links (
    id INTEGER PRIMARY KEY,
    from_url TEXT,
    to_url TEXT
);
"""

def init_db(path=DB_PATH):
    conn = sqlite3.connect(path)
    cur = conn.cursor()
    for q in CREATE_SQL.strip().split(";"):
        if q.strip():
            cur.execute(q)
    conn.commit()
    return conn

def save_page(conn, url, title, status, depth):
    cur = conn.cursor()
    now = datetime.utcnow().isoformat()
    try:
        cur.execute(
            "INSERT OR REPLACE INTO pages (url, title, status, depth, fetched_at) VALUES (?, ?, ?, ?, ?)",
            (url, title, status, depth, now)
        )
        conn.commit()
    except Exception as e:
        print(f"DB save error for {url}: {e}")

def save_link(conn, from_url, to_url):
    cur = conn.cursor()
    try:
        cur.execute("INSERT INTO links (from_url, to_url) VALUES (?, ?)", (from_url, to_url))
        conn.commit()
    except Exception:
        pass

# ---------------- URL NORMALIZATION ----------------
def canonicalize(url):
    try:
        parsed = urlparse(url)
    except Exception:
        return url
    scheme = parsed.scheme.lower()
    netloc = parsed.netloc.lower()
    path = parsed.path or "/"
    upath = unquote(path)
    np = posixpath.normpath(upath)
    if not upath.startswith("/"):
        np = np.lstrip("/")
    if np == ".":
        np = "/"
    if np.endswith("/") and np != "/":
        np = np.rstrip("/")
    safe_path = quote(np, safe="/%:@+,&?;=")
    return urlunparse((scheme, netloc, safe_path, "", parsed.query or "", ""))

def normalize_url(base, href):
    if not href:
        return None
    if href.startswith(("javascript:", "mailto:", "data:", "tel:")):
        return None
    joined = urljoin(base, href)
    joined, _ = urldefrag(joined)
    return canonicalize(joined)

def is_onion(url):
    try:
        p = urlparse(url)
        return p.hostname and p.hostname.endswith(".onion")
    except Exception:
        return False

def allowed_by_robots(url, cache):
    parsed = urlparse(url)
    host = parsed.scheme + "://" + parsed.netloc
    if host in cache:
        rp = cache[host]
        return rp.can_fetch(USER_AGENT, parsed.path or "/")
    robots_url = urljoin(host, "/robots.txt")
    rp = RobotFileParser()
    try:
        r = requests.get(robots_url, proxies=PROXIES, headers=HEADERS, timeout=10)
        rp.parse(r.text.splitlines())
    except Exception:
        rp.parse([])
    cache[host] = rp
    return rp.can_fetch(USER_AGENT, parsed.path or "/")

# ---------------- CRAWLER ----------------
def crawl(seeds, conn, max_pages=MAX_PAGES, max_depth=MAX_DEPTH, delay=DELAY_BETWEEN_REQUESTS):
    q = deque((canonicalize(s), 0) for s in seeds)
    visited = set()
    robots_cache = {}
    pages_crawled = 0

    while q and pages_crawled < max_pages:
        url, depth = q.popleft()
        if url in visited:
            continue
        visited.add(url)

        if not is_onion(url):
            continue

        if not allowed_by_robots(url, robots_cache):
            print(f"[-] Disallowed by robots.txt: {url}")
            continue

        print(f"[+] Fetching (depth={depth}): {url}")
        try:
            r = requests.get(url, proxies=PROXIES, headers=HEADERS, timeout=REQUEST_TIMEOUT)
            status = r.status_code
            if "html" not in r.headers.get("Content-Type", ""):
                save_page(conn, url, None, status, depth)
                continue
            html = r.text
            soup = BeautifulSoup(html, "html.parser")
            title = soup.title.string.strip() if soup.title else None
            save_page(conn, url, title, status, depth)
            pages_crawled += 1

            found = set()

            # 1) Normal <a href>
            for a in soup.find_all("a", href=True):
                nurl = normalize_url(url, a["href"])
                if not nurl:
                    continue
                if is_onion(nurl) or urlparse(nurl).netloc == urlparse(url).netloc:
                    found.add(nurl)
                    save_link(conn, url, nurl)
                    if depth + 1 <= max_depth and nurl not in visited:
                        q.append((nurl, depth + 1))

            # 2) Bare .onion addresses in text
            text = soup.get_text(" ")
            for match in re.findall(r"[a-z2-7]{16,56}\.onion", text):
                onion_url = "http://" + match
                found.add(onion_url)
                save_link(conn, url, onion_url)
                if depth + 1 <= max_depth and onion_url not in visited:
                    q.append((onion_url, depth + 1))

            if found:
                print(f"    -> discovered {len(found)} new links")
            else:
                print("    -> no new links found")

        except Exception as e:
            print(f"[-] Failed {url}: {e}")
            save_page(conn, url, None, 500, depth)

        time.sleep(delay)

    print(f"[!] Crawl finished. Pages crawled: {pages_crawled}")

# ---------------- SEARCH ----------------
def search_db(conn, query, limit=20):
    cur = conn.cursor()
    qlike = f"%{query}%"
    cur.execute(
        "SELECT url, title, status, depth, fetched_at FROM pages "
        "WHERE title LIKE ? OR url LIKE ? LIMIT ?",
        (qlike, qlike, limit),
    )
    return cur.fetchall()

# ---------------- MAIN ----------------
def main():
    print("Ensure Tor is running (default port 9150).")
    print(f"Using proxy: {TOR_SOCKS_PROXY}")
    conn = init_db(DB_PATH)
    crawl(SEED_URLS, conn, max_pages=MAX_PAGES, max_depth=MAX_DEPTH)
    print("\nSearch mode (Ctrl+C to exit).")
    while True:
        try:
            q = input("search> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not q:
            continue
        rows = search_db(conn, q)
        if not rows:
            print("No results.")
        for url, title, status, depth, fetched_at in rows:
            print(f"- [{status}] depth={depth} {title or '<no title>'}\n    {url} (fetched {fetched_at})")

if __name__ == "__main__":
    main()
