import os
import re
import sqlite3
import threading
import time
import random
from queue import Queue
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup
from flask import Flask, render_template_string, request

# -------------------
# Config
# -------------------
START_URLS = [
    "http://zqktlwiuavvvqqt4ybvgvi7tyo4hjl5xgfuvpdf6otjiycgwqbym2qad.onion/wiki/index.php/Main_Page"
]
PROXIES = {"http": "socks5h://127.0.0.1:9150", "https": "socks5h://127.0.0.1:9150"}
DB_FILE = "index.db"
LINKS_FILE = "links.txt"
MAX_DEPTH = 2
MAX_PAGES = 200

# Fake browser headers (Tor Browser / Firefox ESR)
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; rv:102.0) Gecko/20100101 Firefox/102.0",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Connection": "keep-alive",
}

# -------------------
# Database Setup
# -------------------
def init_db():
    conn = sqlite3.connect(DB_FILE, check_same_thread=False)
    c = conn.cursor()
    c.execute(
        """CREATE TABLE IF NOT EXISTS pages (
            id INTEGER PRIMARY KEY,
            url TEXT UNIQUE,
            title TEXT,
            content TEXT,
            depth INTEGER
        )"""
    )
    # Full-text index
    c.execute("CREATE VIRTUAL TABLE IF NOT EXISTS page_index USING fts5(url, title, content)")
    conn.commit()
    return conn


def insert_page(conn, url, title, content, depth):
    c = conn.cursor()
    try:
        c.execute(
            "INSERT OR IGNORE INTO pages (url, title, content, depth) VALUES (?, ?, ?, ?)",
            (url, title, content, depth),
        )
        c.execute(
            "INSERT INTO page_index (url, title, content) VALUES (?, ?, ?)",
            (url, title, content),
        )
        conn.commit()
    except Exception as e:
        print(f"[DB ERROR] {e}")


# -------------------
# Crawler
# -------------------
def extract_onion_links(base_url, html):
    soup = BeautifulSoup(html, "html.parser")
    links = set()
    for tag in soup.find_all("a", href=True):
        href = tag["href"]
        full_url = urljoin(base_url, href)
        if ".onion" in full_url:
            links.add(full_url.split("#")[0])  # remove fragments
    return links


def fetch(url, retries=3, backoff=5):
    """
    Try to fetch a URL through Tor with headers and retry logic.
    """
    for i in range(retries):
        try:
            resp = requests.get(
                url,
                proxies=PROXIES,
                headers=HEADERS,
                timeout=30
            )
            if resp.status_code == 200:
                return resp.text
            else:
                print(f"[!] HTTP {resp.status_code} from {url}")
        except Exception as e:
            print(f"[!] Fetch failed ({i+1}/{retries}): {url} | {e}")
            time.sleep(backoff + random.randint(0, 3))  # wait + jitter

    return None


def crawl_worker(queue, visited, conn):
    pages_crawled = 0
    while not queue.empty() and pages_crawled < MAX_PAGES:
        url, depth = queue.get()
        if url in visited or depth > MAX_DEPTH:
            queue.task_done()
            continue

        visited.add(url)
        print(f"[+] Crawling (depth={depth}): {url}")

        html = fetch(url)
        if not html:
            queue.task_done()
            continue

        soup = BeautifulSoup(html, "html.parser")
        title = soup.title.string.strip() if soup.title else url
        text_content = soup.get_text(" ", strip=True)

        # Save to DB
        insert_page(conn, url, title, text_content, depth)

        # Save to links.txt
        with open(LINKS_FILE, "a", encoding="utf-8") as f:
            f.write(url + "\n")

        # Find and enqueue new links
        for link in extract_onion_links(url, html):
            if link not in visited:
                queue.put((link, depth + 1))

        pages_crawled += 1
        queue.task_done()

        # Random polite delay
        time.sleep(random.uniform(2.0, 5.0))


def start_crawler(conn):
    if os.path.exists(LINKS_FILE):
        os.remove(LINKS_FILE)

    visited = set()
    queue = Queue()
    for url in START_URLS:
        queue.put((url, 0))

    # Run in background thread
    def run():
        while not queue.empty():
            crawl_worker(queue, visited, conn)
        print("[!] Crawler finished.")

    threading.Thread(target=run, daemon=True).start()


# -------------------
# Flask Web App
# -------------------
app = Flask(__name__)
conn = init_db()


@app.route("/", methods=["GET"])
def index():
    query = request.args.get("q", "")
    results = []
    if query:
        c = conn.cursor()
        c.execute(
            "SELECT url, title FROM page_index WHERE page_index MATCH ? LIMIT 20",
            (query,),
        )
        results = c.fetchall()

    return render_template_string(
        """
        <!doctype html>
        <html>
        <head>
            <title>Onion Search</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
                .search-box { margin-bottom: 20px; }
                input[type=text] { width: 300px; padding: 8px; }
                input[type=submit] { padding: 8px 16px; }
                .result { background: #fff; padding: 10px; margin-bottom: 10px; border-radius: 6px; }
                a { text-decoration: none; color: #0066cc; }
            </style>
        </head>
        <body>
            <h1>Onion Search Engine</h1>
            <form class="search-box" method="get">
                <input type="text" name="q" value="{{query}}" placeholder="Search onion sites...">
                <input type="submit" value="Search">
            </form>
            {% for url, title in results %}
                <div class="result">
                    <a href="{{url}}" target="_blank">{{title}}</a><br>
                    <small>{{url}}</small>
                </div>
            {% else %}
                {% if query %}
                    <p>No results found.</p>
                {% endif %}
            {% endfor %}
        </body>
        </html>
        """,
        query=query,
        results=results,
    )


if __name__ == "__main__":
    print("[*] Starting crawler in background...")
    start_crawler(conn)
    print("[*] Starting Flask web app on http://127.0.0.1:5000")
    app.run(port=5000, debug=True)
